'use strict';
/**
 * 华为云 FunctionGraph：直播深测 + 华为云已测标记 + 体育娱乐动态增删 + 点播站判活
 * 触发：每日 4:00
 *
 * 规则：
 *   1. 读 out/candidates.json（3:00 扫源产物）与 config/channels.json
 *   2. 直播深测：m3u8 -> 分片 -> TS 同步 + SPS/PPS/IDR + 第二片（等价"有画面"）
 *   3. 通过的：cloud=ok 打标记；加备线（≤3）；主线失效则顶上（旧线降备不删）
 *   4. 固定四组（央视/卫视/港澳台/武汉）只加不删
 *   5. 体育娱乐组（gid=ent）：有增删权——连续 2 轮主备全死则移出；candidates 里命中体育娱乐关键词
 *      且未在册的，测通即追加
 *   6. 点播：探 13 个采集站三层（接口/条目/真拉片），连续 2 轮判死才从两份 JSON 剔除；
 *      首次上线 VOD_DRYRUN != '0' 只报告不删
 *   7. 写回 channels.json / live.m3u / backup.m3u / cloud-report.json / vod-report.json / vod-history.json
 */

const https = require('https');
const http = require('http');
const zlib = require('zlib');

const BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

const CFG = {
  repo: process.env.REPO || '17993040/media-list',
  token: process.env.GH_TOKEN || '',
  proxy: (process.env.PROXY || 'https://ghproxy.net').replace(/\/$/, ''),
  conc: parseInt(process.env.CONC || '10', 10),
  tmo: parseInt(process.env.TMO || '12000', 10),
  branch: process.env.BRANCH || 'main',
  vodDryRun: (process.env.VOD_DRYRUN || '1') !== '0',
  budget: parseInt(process.env.BUDGET_MS || '780000', 10),
  localProbeOnly: process.env.LOCAL_PROBE_ONLY === '1',
  poolMaxAdd: parseInt(process.env.POOL_MAX_ADD || '10', 10),
  poolMaxPool: parseInt(process.env.POOL_MAX_POOL || '40', 10),
  // 直播找源：自己在国内出口抓直播清单，按台名对齐后补备线
  liveDiscover: (process.env.LIVE_DISCOVER || '1') !== '0',
  liveDiscoverMs: parseInt(process.env.LIVE_DISCOVER_MS || '120000', 10),
  liveCfgMax: parseInt(process.env.LIVE_CFG_MAX || '16', 10),
  liveListMax: parseInt(process.env.LIVE_LIST_MAX || '32', 10),
  liveCandPerCh: parseInt(process.env.LIVE_CAND_PER_CH || '2', 10),
  // 测活硬期限：到点就停，剩下没测的跳过，保证一定走到写回
  liveProbeMs: parseInt(process.env.LIVE_PROBE_MS || '480000', 10),
  // 每台总线路数上限（1 主 + 备线）
  backupMax: parseInt(process.env.BACKUP_MAX || '5', 10),
  // 社区源：每天去 GitHub 拉社区直播清单，只给"待补台"找线
  commMax: parseInt(process.env.COMM_MAX || '12', 10),
  commMs: parseInt(process.env.COMM_MS || '90000', 10),
  commPerCh: parseInt(process.env.COMM_PER_CH || '2', 10),
};

// 体育娱乐组动态识别关键词
const ENT_KW = /体育|足球|篮球|排球|网球|乒乓|羽毛球|电竞|游戏|影视|影院|剧场|戏剧|动漫|动画|卡通|音乐|综艺|娱乐|梨园|戏曲|CHC|FoxSport|Discovery|少儿|电影|纪实|演唱会|演唱会|MV|旅游|美食|纪录/;

function req(url, opts = {}) {
  return new Promise((resolve) => {
    let u;
    try { u = new URL(url); } catch (e) { return resolve({ status: 0, body: Buffer.alloc(0), headers: {}, err: 'bad-url' }); }
    const lib = u.protocol === 'http:' ? http : https;
    const headers = Object.assign({
      'User-Agent': opts.ua || BROWSER_UA,
      'Accept': '*/*',
    }, opts.headers || {});
    const r = lib.request({
      hostname: u.hostname,
      port: u.port || (u.protocol === 'http:' ? 80 : 443),
      path: u.pathname + u.search,
      method: opts.method || 'GET',
      headers,
      timeout: opts.timeout || CFG.tmo,
    }, (res) => {
      const chunks = [];
      let total = 0, done = false;
      const fin = (obj) => { if (done) return; done = true; resolve(obj); };
      res.on('data', (d) => {
        total += d.length;
        if (opts.maxBytes && total > opts.maxBytes) {
          res.destroy();
          fin({ status: res.statusCode || 0, body: Buffer.concat(chunks), headers: res.headers, err: 'max-bytes' });
          return;
        }
        chunks.push(d);
      });
      res.on('end', () => fin({ status: res.statusCode, body: Buffer.concat(chunks), headers: res.headers }));
      res.on('error', (e) => fin({ status: 0, body: Buffer.alloc(0), headers: res.headers, err: String(e) }));
      res.on('close', () => fin({ status: res.statusCode || 0, body: Buffer.concat(chunks), headers: res.headers || {}, err: 'closed' }));
    });
    r.on('timeout', () => { r.destroy(); resolve({ status: 0, body: Buffer.alloc(0), headers: {}, err: 'timeout' }); });
    r.on('error', (e) => resolve({ status: 0, body: Buffer.alloc(0), headers: {}, err: String(e) }));
    if (opts.body) r.write(opts.body);
    r.end();
  });
}

/** 按 content-encoding 解压，采集站多为 gzip，云函数原生 https 不会自动解 */
function decode(r) {
  const raw = r.body || Buffer.alloc(0);
  const enc = String((r.headers && r.headers['content-encoding']) || '').toLowerCase();
  try {
    if (enc.indexOf('br') >= 0) return zlib.brotliDecompressSync(raw);
    if (enc.indexOf('gzip') >= 0) return zlib.gunzipSync(raw);
    if (enc.indexOf('deflate') >= 0) return zlib.inflateSync(raw);
  } catch (e) { /* 落回原始 */ }
  return raw;
}

async function getText(url, opts = {}) {
  const r = await req(url, opts);
  const buf = decode(r);
  return { status: r.status, text: buf.toString('utf8'), body: buf, headers: r.headers || {}, err: r.err };
}

function abs(base, u) {
  try { return new URL(u, base).href; } catch (e) { return u; }
}

function parseM3U8(text) {
  const lines = text.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  const segs = lines.filter(l => !l.startsWith('#'));
  return { segs, isMaster: text.indexOf('#EXT-X-STREAM-INF') >= 0 };
}

function scanNAL(buf) {
  const res = { sps: false, pps: false, idr: false, sei: false };
  const n = Math.min(buf.length - 4, 3 * 1024 * 1024);
  for (let i = 0; i < n; i++) {
    if (buf[i] === 0 && buf[i + 1] === 0 && buf[i + 2] === 1) {
      const t = buf[i + 3] & 0x1f;
      if (t === 7) res.sps = true;
      else if (t === 8) res.pps = true;
      else if (t === 5) res.idr = true;
      else if (t === 6) res.sei = true;
      i += 3;
    }
  }
  return res;
}

function analyzeTS(buf) {
  let off = -1;
  const lim = Math.min(3000, Math.max(0, buf.length - 377));
  for (let i = 0; i < lim; i++) {
    if (buf[i] === 0x47 && buf[i + 188] === 0x47 && buf[i + 376] === 0x47) { off = i; break; }
  }
  if (off < 0) return { ok: false, why: 'no-sync', pk: 0 };
  let pk = 0, good = 0;
  for (let p = off; p + 188 <= buf.length; p += 188) {
    pk++;
    if (buf[p] === 0x47) good++;
  }
  const ratio = pk ? good / pk : 0;
  if (pk < 24) return { ok: false, why: 'few-pk', pk, ratio };
  if (ratio < 0.95) return { ok: false, why: 'bad-sync', pk, ratio };
  const nal = scanNAL(buf.slice(off));
  const hasVideo = nal.sps && nal.idr;
  return { ok: hasVideo, why: hasVideo ? 'keyframe' : 'no-keyframe', pk, ratio, nal };
}

async function deepProbe(url) {
  const r1 = await getText(url, { maxBytes: 2 * 1024 * 1024, timeout: CFG.tmo });
  if (r1.status !== 200 && r1.status !== 206) return { ok: false, stage: 'head', code: r1.status };
  if (!r1.text || r1.text.indexOf('#EXTM3U') < 0) return { ok: false, stage: 'not-m3u8' };

  let text = r1.text;
  let parsed = parseM3U8(text);
  let segs = parsed.segs;
  // master 逐层降，最多 3 层
  for (let depth = 0; parsed.isMaster && segs.length && depth < 3; depth++) {
    const vu = abs(url, segs[0]);
    const r2 = await getText(vu, { maxBytes: 2 * 1024 * 1024, timeout: CFG.tmo });
    if (r2.status !== 200 && r2.status !== 206) return { ok: false, stage: 'variant', code: r2.status };
    text = r2.text;
    parsed = parseM3U8(text);
    segs = parsed.segs;
  }
  if (!segs.length) return { ok: false, stage: 'no-seg' };

  const s1 = abs(url, segs[0]);
  const b1 = await req(s1, { maxBytes: 4 * 1024 * 1024, timeout: CFG.tmo });
  if (!b1.body || b1.body.length < 8192) return { ok: false, stage: 'seg1-small', bytes: b1.body ? b1.body.length : 0 };
  const a1 = analyzeTS(b1.body);
  if (!a1.ok) return { ok: false, stage: 'ts1-' + a1.why, bytes: b1.body.length, pk: a1.pk };

  const s2 = abs(url, segs[Math.min(1, segs.length - 1)]);
  const b2 = await req(s2, { maxBytes: 4 * 1024 * 1024, timeout: CFG.tmo });
  if (!b2.body || b2.body.length < 8192) return { ok: false, stage: 'seg2-small', bytes: b2.body ? b2.body.length : 0 };

  return { ok: true, stage: 'keyframe', bytes: b1.body.length, pk: a1.pk, segs: segs.length };
}

async function poolMap(items, conc, fn) {
  const out = new Array(items.length);
  let idx = 0;
  const workers = new Array(Math.min(conc, items.length)).fill(0).map(async () => {
    while (true) {
      const i = idx++;
      if (i >= items.length) break;
      try { out[i] = await fn(items[i], i); } catch (e) { out[i] = { ok: false, stage: 'err', err: String(e) }; }
    }
  });
  await Promise.all(workers);
  return out;
}

// ---------- GitHub 读写 ----------
async function ghRawGet(path) {
  const url = `${CFG.proxy}/https://raw.githubusercontent.com/${CFG.repo}/${CFG.branch}/${path}?t=${Date.now()}`;
  const r = await getText(url, { maxBytes: 8 * 1024 * 1024, headers: { Authorization: `token ${CFG.token}` } });
  return { status: r.status, text: r.text };
}

async function ghApiGet(path) {
  const r = await getText(`https://api.github.com/repos/${CFG.repo}/contents/${path}?ref=${CFG.branch}`, {
    headers: { Authorization: `token ${CFG.token}`, Accept: 'application/vnd.github+json' },
    maxBytes: 8 * 1024 * 1024,
  });
  if (r.status !== 200) return { status: r.status, sha: '', text: '' };
  let j;
  try { j = JSON.parse(r.text); } catch (e) { return { status: 0, sha: '', text: '' }; }
  const content = Buffer.from(j.content || '', 'base64').toString('utf8');
  return { status: 200, sha: j.sha || '', text: content };
}

async function ghPut(path, content, sha, msg) {
  const body = JSON.stringify({
    message: msg,
    content: Buffer.from(content, 'utf8').toString('base64'),
    sha: sha || undefined,
    branch: CFG.branch,
  });
  const bufs = Buffer.from(body, 'utf8');
  const r = await req(`https://api.github.com/repos/${CFG.repo}/contents/${path}`, {
    method: 'PUT',
    headers: {
      Authorization: `token ${CFG.token}`,
      Accept: 'application/vnd.github+json',
      'Content-Type': 'application/json',
      'Content-Length': bufs.length,
      'User-Agent': 'hw-live-sync/3',
    },
    body: bufs,
    maxBytes: 2 * 1024 * 1024,
    timeout: 20000,
  });
  return r.status;
}

function buildM3U(chs) {
  let s = '#EXTM3U\n';
  for (const c of chs) {
    let label = c.name;
    if (!c.main) label = c.name + '〔待补〕';
    else if (c.cloud === 'ok') label = c.name + '[华为云已测]';
    const u = c.main || 'http://0.0.0.0:1/void.m3u8';
    s += `#EXTINF:-1 group-title="${c.group}",${label}\n${u}\n`;
  }
  return s;
}

function buildBck(chs) {
  let s = '#EXTM3U\n';
  for (const c of chs) {
    for (const b of (c.backup || [])) {
      if (!b) continue;
      s += `#EXTINF:-1 group-title="${c.group}",${c.name}〔备〕\n${b}\n`;
    }
  }
  return s;
}

// ---------- 体育娱乐组：动态增删 ----------
async function maintainEnt(chs, cands, ts, say) {
  const ent = chs.filter(c => c.gid === 'ent' || c.group === '体育娱乐');
  if (!ent.length) return { tested: 0, removed: [], added: [], relinked: 0 };

  // 1) 测现有台的所有线（main + backup，最多 3 条）
  const probes = await poolMap(ent, Math.min(CFG.conc, 3), async (c) => {
    const urls = [];
    if (c.main) urls.push(c.main);
    for (const b of (c.backup || [])) { if (b) urls.push(b); }
    const hits = [];
    for (const u of urls.slice(0, 1 + CFG.backupMax)) {
      onProgress: {
        const r = await deepProbe(u);
        hits.push({ url: u, ok: r.ok, stage: r.stage });
        if (r.ok) break; // 找到活的就停
      }
    }
    const alive = hits.filter(h => h.ok);
    return { ch: c, hits, alive };
  });

  const removed = [], relinked = [];
  for (const p of probes) {
    const c = p.ch;
    if (p.alive.length) {
      c.failCount = 0;
      c.lastCloud = ts;
      c.cloud = 'ok';
      const best = p.alive[0].url;
      if (c.main !== best) {
        // 现有主线死了，活的备线顶上，旧主线降备
        const bk = (c.backup || []).filter(x => x !== best && x !== c.main);
        if (c.main) bk.unshift(c.main);
        while (bk.length > CFG.backupMax) bk.pop();
        c.main = best;
        c.backup = bk;
        c.note = '云端顶上';
        relinked.push(c.name);
      }
      continue;
    }
    // 全死
    c.failCount = (c.failCount || 0) + 1;
    c.lastCloud = ts;
    c.note = `云端连续判死 ${c.failCount} 轮`;
    if (c.failCount >= 2) removed.push({ name: c.name, main: c.main, stage: p.hits.map(h => h.stage).join('/') });
  }

  // 2) 从 candidates 里补：命中关键词、未在册、测通即加
  const existNames = new Set(chs.map(c => c.name));
  const themeCands = cands.filter(x => x.name && ENT_KW.test(x.name) && !existNames.has(x.name));
  let added = [];
  if (themeCands.length) {
    const checked = await poolMap(themeCands, Math.min(CFG.conc, 6), async (x) => {
      const r = await deepProbe(x.url);
      return Object.assign({ cand: x }, r);
    });
    let maxSeq = chs.reduce((m, c) => Math.max(m, parseInt(c.seq || 0, 10)), 0);
    for (const r of checked) {
      if (!r.ok) continue;
      if (chs.some(c => c.name === r.cand.name)) continue;
      maxSeq++;
      chs.push({
        seq: maxSeq, group: '体育娱乐', gid: 'ent', name: r.cand.name,
        main: r.cand.url, backup: [], local: 'untested', cloud: 'ok',
        must: false, failCount: 0, lastLocal: '', lastCloud: ts, note: '云端新增',
      });
      added.push(r.cand.name);
    }
  }

  // 3) 执行删除（只删 ent 组）
  let deletedNames = [];
  if (removed.length) {
    for (const r of removed) {
      const i = chs.findIndex(c => c.name === r.name && (c.gid === 'ent' || c.group === '体育娱乐'));
      if (i >= 0) { chs.splice(i, 1); deletedNames.push(r.name); }
    }
    // 重排 seq
    chs.forEach((c, i) => { c.seq = i + 1; });
  }

  say(`体育娱乐：在册 ${ent.length} 测 ${probes.length} 换线 ${relinked.length} 新增 ${added.length} 移出 ${deletedNames.length}`);
  return { tested: ent.length, removed: deletedNames, added, relinked: relinked.length };
}

// ---------- 直播：自己找源（按台名对齐，补备线） ----------

// 直播清单里港澳台基本是繁体，先转简体再对齐，否则一台都配不上
const T2S_FROM = '臺視聞東衛體戲劇電亞華麗灣綜藝頻際國陸財經龍鳳歲萬與為業廣門開關這個點線號紀錄實區變訊動場報進選戰環節總聯網遊優勢獎會來時間問題學習讀寫說話題貝頁類黨團員師專陳張劉黃吳鄭謝許馮葉鐘韓齊魯蘇兒樂鳥魚馬車長飛風雲錢陽雙難雖隨險隱雜雞離靈靜頂順須頭顯飯飲館綫廈遼寧陝贛閩粵晉滬貴肅瓊隴歡慶鹽';
const T2S_TO = '台视闻东卫体戏剧电亚华丽湾综艺频际国陆财经龙凤岁万与为业广门开关这个点线号纪录实区变讯动场报进选战环节总联网游优势奖会来时间问题学习读写说话题贝页类党团员师专陈张刘黄吴郑谢许冯叶钟韩齐鲁苏儿乐鸟鱼马车长飞风云钱阳双难虽随险隐杂鸡离灵静顶顺须头显饭饮馆线厦辽宁陕赣闽粤晋沪贵肃琼陇欢庆盐';

function t2s(s) {
  const str = String(s || '');
  let out = '';
  for (const ch of str) {
    const i = T2S_FROM.indexOf(ch);
    out += i >= 0 ? T2S_TO.charAt(i) : ch;
  }
  return out;
}

const _chKeyCache = new Map();

/** 台名归一化键：CCTV 走数字（+ 保留），其它转简体、去掉高清/括号等修饰 */
function chKey(name) {
  const raw = String(name || '').trim();
  if (!raw) return '';
  const cached = _chKeyCache.get(raw);
  if (cached !== undefined) return cached;
  let out = '';
  do {
    const cctv = raw.match(/CCTV[\s\-_]*(\d+)\s*(\+)?/i);
    if (cctv) { out = 'CCTV' + parseInt(cctv[1], 10) + (cctv[2] ? 'P' : ''); break; }
    if (/^CGTN/i.test(raw)) { out = 'CGTN'; break; }
    out = t2s(raw)
      .replace(/[（(][^)）]*[)）]/g, '')
      .replace(/【[^】]*】/g, '')
      .replace(/[「『][^」』]*[」』]/g, '')
      .toUpperCase()
      .replace(/[\s\-_·、,，.。:：'"“”]/g, '')
      .replace(/(高清|超清|蓝光|标清|1080P|720P|4K|8K|HDR|HD|SD)/g, '')
      .trim();
  } while (false);
  _chKeyCache.set(raw, out);
  return out;
}

/** 允许"多出来"的部分：只认通用后缀，避免湖南卫视国际被并到湖南卫视 */
const CH_TAIL_OK = /^(综合|频道|台|一套|1套|二套|2套|三套|3套|剧场|电影|体育|新闻|少儿|纪录|纪实)$/;

function matchChannel(chs, name) {
  const k = chKey(name);
  if (!k) return null;
  for (const c of chs) if (chKey(c.name) === k) return c;
  for (const c of chs) {
    const ck = chKey(c.name);
    if (!ck || ck === k) continue;
    if (ck.length > k.length && ck.startsWith(k)) {
      const tail = ck.slice(k.length);
      if (tail.length <= 4 && CH_TAIL_OK.test(tail)) return c;
    }
    if (k.length > ck.length && k.startsWith(ck)) {
      const tail = k.slice(ck.length);
      if (tail.length <= 4 && CH_TAIL_OK.test(tail)) return c;
    }
  }
  return null;
}

/** 解析 m3u 或 txt 直播清单，返回 [{name,url}] */
function parseLivePlaylist(text, baseUrl) {
  const out = [];
  if (!text || text.length < 40) return out;
  if (text.indexOf('#EXTINF') >= 0 || text.indexOf('#EXTM3U') >= 0) {
    let pending = '';
    for (const raw of text.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line) continue;
      if (line.charAt(0) === '#') {
        if (line.indexOf('#EXTINF') === 0) {
          const idx = line.lastIndexOf(',');
          const nm = idx >= 0 ? line.slice(idx + 1) : '';
          const tvg = line.match(/tvg-name="([^"]+)"/i);
          pending = (nm && nm.trim()) || (tvg ? tvg[1] : '') || '';
        }
        continue;
      }
      if (pending && /^https?:\/\//i.test(line)) out.push({ name: pending, url: abs(baseUrl, line) });
      pending = '';
    }
    return out;
  }
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.charAt(0) === '#') continue;
    const idx = line.indexOf(',');
    if (idx < 0) continue;
    const name = line.slice(0, idx).trim();
    const u = line.slice(idx + 1).trim();
    if (!name || !u || u.indexOf('#genre#') >= 0) continue;
    if (!/^https?:\/\//i.test(u)) continue;
    out.push({ name, url: u });
  }
  return out;
}

/**
 * 抓活配置 → 抽直播清单 → 下载 → 按台名对齐 → 返回"该台还没有的新线路"
 * 这是把原来 3:00 在 GitHub 上做的扫源，搬到国内出口的云函数里做。
 */
async function discoverLiveSources(chs, say) {
  const t0 = Date.now();
  const defs = (typeof VOD_CFG_URLS !== 'undefined' ? VOD_CFG_URLS : []).slice(0, CFG.liveCfgMax);
  const listUrls = [];
  const inline = [];
  let cfgOk = 0;

  const cfgBatch = 8;
  for (let i = 0; i < defs.length; i += cfgBatch) {
    if (Date.now() - t0 > CFG.liveDiscoverMs) break;
    const seg = defs.slice(i, i + cfgBatch);
    const texts = await Promise.all(seg.map(async (u) => {
      const r = await getText(u, { timeout: 15000, maxBytes: 4 * 1024 * 1024 });
      if (r.status !== 200 || !r.text || r.text.length < 80) return null;
      return r.text;
    }));
    for (let k = 0; k < texts.length; k++) {
      const t = texts[k];
      if (!t) continue;
      cfgOk++;
      let j = null;
      try { j = JSON.parse(t); } catch (e) { j = null; }
      if (j && Array.isArray(j.lives)) {
        for (const L of j.lives) {
          if (!L) continue;
          if (typeof L === 'string' && /^https?:\/\//i.test(L)) { listUrls.push(L); continue; }
          if (L.url && /^https?:\/\//i.test(String(L.url))) listUrls.push(String(L.url));
          if (Array.isArray(L.channels)) {
            for (const ch of L.channels) {
              const urls = [].concat(ch && ch.urls ? ch.urls : [], ch && ch.url ? [ch.url] : []);
              for (const u of urls) {
                const s = String(u || '').trim();
                if (/^https?:\/\//i.test(s)) inline.push({ name: ch.name || '', url: s });
              }
            }
          }
        }
      } else {
        // 非 JSON 的 box/txt：正则抽直播清单地址
        const rx = /https?:\/\/[^\s"'<>，]+?\.(?:m3u8?|txt)(?:\?[^\s"'<>，]*)?/ig;
        let m;
        while ((m = rx.exec(t)) !== null) {
          if (m[0].length < 500) listUrls.push(m[0]);
        }
      }
    }
  }

  const uniqLists = Array.from(new Set(listUrls)).slice(0, CFG.liveListMax);
  let listOk = 0;
  const pairs = [];
  const listBatch = 10;
  for (let i = 0; i < uniqLists.length; i += listBatch) {
    if (Date.now() - t0 > CFG.liveDiscoverMs) break;
    const seg = uniqLists.slice(i, i + listBatch);
    const texts = await Promise.all(seg.map(async (u) => {
      const r = await getText(u, { timeout: 15000, maxBytes: 6 * 1024 * 1024 });
      if (r.status !== 200 || !r.text || r.text.length < 60) return null;
      return r.text;
    }));
    for (let k = 0; k < texts.length; k++) {
      if (!texts[k]) continue;
      listOk++;
      const ps = parseLivePlaylist(texts[k], seg[k]);
      for (const p of ps) pairs.push(p);
      if (pairs.length > 40000) break;
    }
  }
  for (const p of inline) pairs.push(p);

  say(`直播找源：配置 ${cfgOk}/${defs.length} 读通，清单 ${listOk}/${uniqLists.length} 下载，频道条目 ${pairs.length}`);

  // 按台名对齐，每台最多留 liveCandPerCh 条、且尽量不同 host
  const cands = [];
  let matchTry = 0, matchHit = 0;
  const perCh = {};
  const seenUrl = new Set();
  const chUrls = new Map();
  for (const c of chs) {
    const have = new Set();
    if (c.main) have.add(c.main);
    for (const b of (c.backup || [])) if (b) have.add(b);
    chUrls.set(c, have);
  }
  let dropDomain = 0;
  for (const p of pairs) {
    matchTry++;
    const u = String(p.url || '').trim();
    if (!u || seenUrl.has(u)) continue;
    // 只信国内 IP 直连：内网段、组播段、域名源一律丢掉（域名源多是外网跳转，从国内拉不动）
    if (!isCnDirect(u)) { dropDomain++; continue; }
    seenUrl.add(u);
    const c = matchChannel(chs, p.name);
    if (!c) continue;
    matchHit++;
    const have = chUrls.get(c);
    if (have.has(u)) continue;
    // 已经够线的不再补，优先补给裸台
    const curLines = (c.main ? 1 : 0) + (c.backup || []).filter(Boolean).length;
    if (curLines >= 1 + CFG.backupMax) continue;
    const isTsPath = u.indexOf('/tsfile/') >= 0;
    const cap = isTsPath ? CFG.liveCandPerCh : 1;
    const cnt = perCh[c.name] || 0;
    if (cnt >= cap) continue;
    perCh[c.name] = cnt + 1;
    have.add(u);
    cands.push({ name: c.name, url: u, from: isTsPath ? 'tsfile' : 'ip-m3u8' });
  }

  const chsHit = Object.keys(perCh).length;
  say(`直播找源：命中 ${chsHit}/${chs.length} 台，新候选 ${cands.length} 条（匹配尝试 ${matchTry}，对上 ${matchHit}，丢弃非国内IP ${dropDomain}）`);
  return {
    cfgOk, cfgTried: defs.length, listOk, listTried: uniqLists.length,
    pairs: pairs.length, chsHit, cands, ms: Date.now() - t0,
    matchTry, matchHit,
    samples: Array.from(new Set(pairs.slice(0, 2000).map(p => String((p && p.name) || '').trim()))).slice(0, 25),
  };
}

// ---------- 直播：编号表复刻（同格式源站共用一套编号，学到一次就能全站复用） ----------

// 已验证可下载、且带台名的直播清单（前 5 个是每天自动更新的仓库）
const LIVE_LIST_URLS = [
  'https://ghproxy.net/https://raw.githubusercontent.com/iptv-org/iptv/master/streams/cn.m3u',
  'https://ghproxy.net/https://raw.githubusercontent.com/fanmingming/live/main/tv/m3u/ipv6.m3u',
  'https://ghproxy.net/https://raw.githubusercontent.com/vbskycn/iptv/master/tv/iptv4.m3u',
  'https://ghproxy.net/https://raw.githubusercontent.com/hujingguang/ChinaIPTV/main/cnTV_AutoUpdate.m3u8',
  'https://ghproxy.net/https://raw.githubusercontent.com/ssili126/tv/main/itvlist.txt',
  'https://ghproxy.net/https://raw.githubusercontent.com/suxuang/myIPTV/main/ipv4.m3u',
  'https://ghproxy.net/https://raw.githubusercontent.com/YanG-1989/m3u/main/Gather.m3u',
  'https://ghproxy.net/https://raw.githubusercontent.com/Guovin/iptv-api/gd/output/result.m3u',
  'https://ghproxy.net/https://raw.githubusercontent.com/ne7359/tvurl/main/list.m3u',
  'https://ghproxy.net/https://raw.githubusercontent.com/Supprise0901/TVBox_live/main/live.txt',
];

/** 只要国内 IP 直连的线路；域名源（多为外网/跳转页）一律不收，省测活预算 */
function isCnDirect(u) {
  try {
    const h = new URL(u).hostname;
    if (!/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(h)) return false;
    if (/^(0\.|10\.|127\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|22[4-9]\.|2[3-5]\d\.|192\.0\.2\.)/.test(h)) return false;
    return true;
  } catch (e) { return false; }
}

const CODEBOOK_PATH = 'config/live-codebook.json';
// 人工抽帧确认过的"host:port → {编号: 实测台名}"，优先于学来的编号表
const VERIFIED_PATH = 'config/live-verified.json';
const TS_RX = /^https?:\/\/([^\/:]+):(\d+)\/tsfile\/live\/(\d+)_\d+/;

// 只有这几个端口的编号表是从带台名清单直接对出来、并核对过的；
// 其它端口（尤其 9901）的映射是反推学来的，同一个编号在不同源站含义不同，
// 直接挂到台上会串台，所以一律进"待选池"，等本地抽帧鉴定后再转正
const TRUSTED_PORTS = new Set(['50085', '85', '8445']);

/** 清单 + 已确认映射 → 每个端口一套"编号→台名"表（票多者胜） */
function learnCodebook(chs, pairs, oldPorts) {
  const ports = {};
  for (const p of Object.keys(oldPorts || {})) ports[p] = Object.assign({}, oldPorts[p]);
  const votes = new Map();

  const vote = (port, code, name) => {
    if (!port || !code || !name) return;
    if (!votes.has(port)) votes.set(port, new Map());
    const cm = votes.get(port);
    if (!cm.has(code)) cm.set(code, new Map());
    const cnt = cm.get(code);
    cnt.set(name, (cnt.get(name) || 0) + 1);
  };

  // 1) 在册已确认的线（权重最高，直接定表）
  for (const c of chs) {
    for (const u of [c.main].concat(c.backup || [])) {
      const mm = u ? String(u).match(TS_RX) : null;
      if (!mm) continue;
      if (!ports[mm[2]]) ports[mm[2]] = {};
      ports[mm[2]][mm[3]] = c.name;
    }
  }

  // 2) 清单里的 tsfile 地址投票
  for (const p of pairs) {
    const mm = String((p && p.url) || '').match(TS_RX);
    if (!mm) continue;
    const nm = String((p && p.name) || '').trim();
    if (!nm) continue;
    vote(mm[2], mm[3], nm);
  }

  let added = 0, changed = 0;
  for (const [port, cm] of votes) {
    if (!ports[port]) ports[port] = {};
    for (const [code, cnt] of cm) {
      let best = '', bc = 0;
      for (const [n, c] of cnt) if (c > bc) { bc = c; best = n; }
      const cur = ports[port][code];
      if (!cur) { ports[port][code] = best; added++; }
      else if (cur !== best && bc >= 2) { ports[port][code] = best; changed++; }
    }
  }
  return { ports, added, changed };
}

/** 用编号表 × 源站池 批量造候选（每台只补到上限，避免测炸预算）
 *  verified：人工抽帧确认过的 host:port → {编号: 台名}。命中就用实测台名，且算可信；
 *  实测表里写成 null 的编号表示"看不出"，直接跳过不造。 */
function buildCodebookCands(chs, ports, stations, verified) {
  const byName = new Map(chs.map(c => [c.name, c]));
  const existing = new Set();
  for (const c of chs) {
    if (c.main) existing.add(c.main);
    for (const b of (c.backup || [])) if (b) existing.add(b);
  }
  const vAll = verified || {};
  const cands = [];
  const perCh = {};
  for (const st of stations) {
    const book = ports[st.port] || {};
    const vBook = vAll[st.host + ':' + st.port] || null;
    const codeList = [];
    if (vBook) for (const k of Object.keys(vBook)) codeList.push(k);
    for (const k of Object.keys(book)) if (codeList.indexOf(k) < 0) codeList.push(k);
    for (const code of codeList) {
      const hasV = vBook && Object.prototype.hasOwnProperty.call(vBook, code);
      let name, trusted;
      if (hasV) {
        if (!vBook[code]) continue;
        name = vBook[code];
        trusted = true;
      } else {
        name = book[code];
        trusted = TRUSTED_PORTS.has(String(st.port));
      }
      if (!name) continue;
      const c = byName.get(name);
      if (!c) continue;
      const hasThis = [c.main].concat(c.backup || []).some(u =>
        u && String(u).indexOf(`http://${st.host}:${st.port}/tsfile/live/${code}_`) === 0);
      if (hasThis) continue;
      const curLines = (c.main ? 1 : 0) + (c.backup || []).filter(Boolean).length;
      if (curLines >= 1 + CFG.backupMax) continue;
      if ((perCh[name] || 0) >= CFG.liveCandPerCh) continue;
      const playlive = st.port === '50085' ? 0 : 1;
      const url = `http://${st.host}:${st.port}/tsfile/live/${code}_1.m3u8?key=txiptv&playlive=${playlive}&authid=0`;
      if (existing.has(url)) continue;
      existing.add(url);
      perCh[name] = (perCh[name] || 0) + 1;
      cands.push({ name, url, from: 'codebook', port: String(st.port), trusted });
    }
  }
  return cands;
}

/** 抓带台名清单 → 学编号表 → 用同格式源站批量造候选 */
async function discoverByCodebook(chs, say, verified) {
  const t0 = Date.now();
  const pairs = [];
  let listOk = 0;
  const batch = 3;
  for (let i = 0; i < LIVE_LIST_URLS.length; i += batch) {
    if (Date.now() - t0 > CFG.liveDiscoverMs) break;
    const seg = LIVE_LIST_URLS.slice(i, i + batch);
    const texts = await Promise.all(seg.map(u => getText(u, { timeout: 20000, maxBytes: 8 * 1024 * 1024 })));
    for (let k = 0; k < texts.length; k++) {
      const r = texts[k];
      if (r.status !== 200 || !r.text || r.text.length < 60) continue;
      listOk++;
      for (const p of parseLivePlaylist(r.text, seg[k])) pairs.push(p);
    }
  }
  say(`编号表：清单 ${listOk}/${LIVE_LIST_URLS.length} 下载，条目 ${pairs.length}`);

  // 历史表（没有就是空）
  let oldPorts = {};
  let oldStations = [];
  let cbRaw = { sha: '', text: '' };
  try {
    cbRaw = await ghApiGet(CODEBOOK_PATH);
    if (cbRaw.status === 200 && cbRaw.text) {
      const j = JSON.parse(cbRaw.text);
      oldPorts = (j && j.ports) || {};
      oldStations = Array.isArray(j && j.stations) ? j.stations : [];
    }
  } catch (e) { oldPorts = {}; }

  const learned = learnCodebook(chs, pairs, oldPorts);
  const totalCodes = Object.keys(learned.ports).reduce((a, p) => a + Object.keys(learned.ports[p]).length, 0);
  say(`编号表：${Object.keys(learned.ports).length} 套表 / ${totalCodes} 条对应（新增 ${learned.added}，改判 ${learned.changed}）`);

  // 源站池：清单里出现的 + 在册已用的
  const stMap = new Map();
  for (const p of pairs) {
    const s = String((p && p.url) || '');
    const mm = s.match(TS_RX);
    if (mm) { stMap.set(mm[1] + ':' + mm[2], { host: mm[1], port: mm[2] }); continue; }
    // 同格式源站也可能走 /hls/ 等其它路径：只要是国内 IP 就把 host:port 收进池（端口有编号表才会用到）
    const hd = s.match(/^https?:\/\/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d+)\//);
    if (hd && isCnDirect(s)) stMap.set(hd[1] + ':' + hd[2], { host: hd[1], port: hd[2] });
  }
  for (const c of chs) {
    for (const u of [c.main].concat(c.backup || [])) {
      const mm = u ? String(u).match(TS_RX) : null;
      if (mm) stMap.set(mm[1] + ':' + mm[2], { host: mm[1], port: mm[2] });
    }
  }
  // 历史学到的源站也留在池里（不重新探测，直接复用编号表，池子不会越跑越窄）
  for (const s of oldStations) {
    const mm = String(s || '').match(/^(\d{1,3}(?:\.\d{1,3}){3}):(\d+)$/);
    if (mm) stMap.set(mm[1] + ':' + mm[2], { host: mm[1], port: mm[2] });
  }
  const stations = Array.from(stMap.values());
  const cands = buildCodebookCands(chs, learned.ports, stations, verified);
  const trustedCnt = cands.filter(c => c.trusted).length;
  say(`编号表：源站 ${stations.length} 个，造出候选 ${cands.length} 条，覆盖 ${new Set(cands.map(c => c.name)).size} 台（可直接挂 ${trustedCnt} 条，其余进待选）`);

  // 写回表（本地空跑不写）
  let push = 0;
  if (!CFG.localProbeOnly && (learned.added || learned.changed)) {
    const body = JSON.stringify({
      updated: new Date().toISOString(),
      ports: learned.ports,
      stations: stations.map(s => s.host + ':' + s.port),
    }, null, 2);
    try { push = await ghPut(CODEBOOK_PATH, body, cbRaw.sha || '', 'live: 编号表 ' + new Date().toISOString()); } catch (e) { push = 0; }
  }

  return {
    listOk, listTried: LIVE_LIST_URLS.length, pairs: pairs.length,
    ports: Object.keys(learned.ports).length, codes: totalCodes,
    added: learned.added, changed: learned.changed,
    stations: stations.length, cands, push, ms: Date.now() - t0,
  };
}

// ---------- 社区源：去 GitHub 拉社区直播清单，只给"待补台"找线 ----------
const COMMUNITY_PATH = 'config/live-sources.json';

// 社区源多是域名/中转，不能套 isCnDirect（那只放行国内 IP）；这里只排私网和非法
function isUsableUrl(u) {
  try {
    const h = new URL(u).hostname;
    if (!h) return false;
    if (/^(localhost|127\.|0\.|10\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(h)) return false;
    if (/^(raw\.githubusercontent\.com|ghproxy\.net|github\.com)$/.test(h)) return false;
    return true;
  } catch (e) { return false; }
}

async function discoverFromCommunity(chs, say) {
  const t0 = Date.now();
  const bare = new Set(chs.filter(c => !c.main).map(c => c.name));
  if (!bare.size) { say('社区源：本轮没有待补台，跳过'); return { tried: 0, ok: 0, pairs: 0, chs: 0, cands: [], ms: 0 }; }

  let cfg = null;
  try {
    const r = await ghApiGet(COMMUNITY_PATH);
    if (r.status === 200 && r.text) cfg = JSON.parse(r.text);
  } catch (e) { say('社区源：配置读取异常 ' + String(e).slice(0, 60)); }
  const arr = cfg && (cfg.urls || cfg.sources) ? (cfg.urls || cfg.sources) : (Array.isArray(cfg) ? cfg : []);
  const list = arr.map(x => String(x || '').trim()).filter(x => /^https?:\/\//i.test(x)).slice(0, CFG.commMax);
  if (!list.length) { say('社区源：配置为空，跳过'); return { tried: 0, ok: 0, pairs: 0, chs: 0, cands: [], ms: 0 }; }

  let ok = 0;
  const pairs = [];
  for (let i = 0; i < list.length; i += 4) {
    if (Date.now() - t0 > CFG.commMs) { say('社区源：到时间上限，提前收手'); break; }
    const seg = list.slice(i, i + 4);
    const got = await Promise.all(seg.map(async (u) => {
      let r = await getText(u, { timeout: 12000, maxBytes: 8 * 1024 * 1024 });
      if (!(r.status === 200 && r.text && r.text.length > 200) && /raw\.githubusercontent\.com$|raw\.githubusercontent\.com\//.test(u)) {
        // 华为云出口拉 raw 常超时，套镜像再试一次
        r = await getText('https://ghproxy.net/' + u, { timeout: 16000, maxBytes: 8 * 1024 * 1024 });
      }
      if (r.status !== 200 || !r.text || r.text.length < 200) return null;
      return { u, t: r.text };
    }));
    for (const x of got) {
      if (!x) continue;
      ok++;
      for (const p of parseLivePlaylist(x.t, x.u)) pairs.push(p);
    }
  }
  say(`社区源：拉取 ${ok}/${list.length}，条目 ${pairs.length}`);

  const cands = [];
  const seenUrl = new Set();
  const per = {};
  for (const p of pairs) {
    if (!p || !p.url || !p.name) continue;
    if (!isUsableUrl(p.url)) continue;
    const c = matchChannel(chs, p.name);
    if (!c || !bare.has(c.name)) continue;
    if (seenUrl.has(p.url)) continue;
    if ((per[c.name] || 0) >= CFG.commPerCh) continue;
    seenUrl.add(p.url);
    per[c.name] = (per[c.name] || 0) + 1;
    cands.push({ name: c.name, url: p.url, from: 'community', trusted: true });
  }
  const hit = Object.keys(per).length;
  say(`社区源：覆盖待补 ${hit} 台，造出候选 ${cands.length} 条`);
  return { tried: list.length, ok, pairs: pairs.length, chs: hit, cands, ms: Date.now() - t0 };
}

// ---------- 点播：判活 + 回写 ----------
function vodUrlOf(site) {
  return site.api || site.url || '';
}
function vodNameOf(site) {
  return site.name || site.key || '';
}

// 活配置清单：TVBox 生态每天在维护的配置，里面正在用的采集站 = 当前大概率还活的站
const VOD_CFG_URLS = [
  'https://ghproxy.net/https://raw.githubusercontent.com/zhoujck/config/main/box',
  'https://ghproxy.net/https://raw.githubusercontent.com/gaotianliuyun/gao/master/XYQ.json',
  'https://ghproxy.net/https://raw.githubusercontent.com/gaotianliuyun/gao/master/js.json',
  'https://ghproxy.net/https://raw.githubusercontent.com/gaotianliuyun/gao/master/0827.json',
  'https://ghproxy.net/https://raw.githubusercontent.com/dxawi/0/main/0.json',
  'https://ghproxy.net/https://raw.githubusercontent.com/guot55/yg/main/pg/bh.json',
  'https://www.cttv.vip/ys/json/ctys.json',
  'https://ztha.top/TVBox/thdjk.json',
  'https://clun.top/box.json',
  'https://szyyds.cn/tv/x.json',
  'https://6800.kstore.vip/fish.json',
  'https://9280.kstore.vip/aiwex.json',
  'https://9763.kstore.vip/aowu.json',
  'https://7337.kstore.vip/xw/api.json',
  'https://www.yingm.cc/dm/dm.json',
  'https://play.iptv365.org/%E9%A6%99%E9%9B%85%E9%9B%9C%E6%83%85/api.json',
];

const VOD_API_RX = /https?:\/\/[A-Za-z0-9.\-_]+(?::\d+)?(?:\/[A-Za-z0-9_\-\/.]*)?\/api\.php\/provide\/vod[A-Za-z0-9_\-.\/]*/g;

/**
 * 每轮都跑一次"找源"：抓活配置 → 正则抽 MacCMS 采集站 → 按域名去重计数。
 * 云端在广州，连国内配置源和采集站比 GitHub runner 通得多，所以找源放在这里做。
 */
async function discoverVodSources(say) {
  let list = VOD_CFG_URLS.slice();
  try {
    const raw = await ghApiGet('config/vod-config-sources.json');
    if (raw.status === 200 && raw.text) {
      const j = JSON.parse(raw.text);
      if (Array.isArray(j.sources) && j.sources.length) list = j.sources;
      if (j.max) list = list.slice(0, parseInt(j.max, 10) || list.length);
    }
  } catch (e) { /* 没有清单文件就用内置 */ }

  const found = new Map();
  let ok = 0;
  let fail = 0;
  const batch = 6;
  for (let i = 0; i < list.length; i += batch) {
    const seg = list.slice(i, i + batch);
    const texts = await Promise.all(seg.map(async (u) => {
      const r = await getText(u, { timeout: 15000, maxBytes: 3 * 1024 * 1024 });
      if (r.status !== 200 || !r.text || r.text.length < 200) return null;
      return r.text;
    }));
    for (const t of texts) {
      if (!t) { fail++; continue; }
      ok++;
      VOD_API_RX.lastIndex = 0;
      let m;
      while ((m = VOD_API_RX.exec(t)) !== null) {
        const api = m[0].replace(/\\\//g, '/');
        let host = '';
        try { host = new URL(api).host; } catch (e) { continue; }
        if (!host) continue;
        const cur = found.get(host);
        if (cur) {
          cur.count++;
          if (api.length > cur.api.length) cur.api = api;
        } else {
          found.set(host, { host, api, count: 1 });
        }
      }
    }
  }

  const arr = Array.from(found.values()).sort((a, b) => b.count - a.count);
  say(`点播找站：配置 ${ok}/${list.length} 读通，抽到采集站 ${arr.length} 个域名`);
  if (arr.length) say('  引用最多的：' + arr.slice(0, 6).map(h => `${h.host}(${h.count}x)`).join('、'));
  return { ok, fail, tried: list.length, hosts: arr };
}

async function vodProbe(site) {
  const base = vodUrlOf(site);
  if (!base) return { ok: false, stage: 'no-url' };

  // 苹果CMS：at/json 裸路径只给列表页（无播放地址），要 ac=detail 才带 vod_play_url
  const sep = base.indexOf('?') >= 0 ? '&' : '?';
  const variants = [base + sep + 'ac=detail', base + sep + 'ac=videolist', base];
  let last = { ok: false, stage: 'unknown' };

  for (const url of variants) {
    const r = await getText(url, {
      headers: { 'Accept-Encoding': 'identity', Accept: 'application/json,text/plain,*/*' },
      maxBytes: 8 * 1024 * 1024,
      timeout: 20000,
    });
    if (r.status !== 200) { last = { ok: false, stage: 'http', code: r.status, err: r.err || '' }; continue; }

    let text = r.text;
    if (!text.trim().startsWith('{') && !text.trim().startsWith('[')) {
      try { text = zlib.gunzipSync(r.body).toString('utf8'); } catch (e) { /* ignore */ }
    }
    const head = text.trim().slice(0, 1);
    if (head !== '{' && head !== '[') { last = { ok: false, stage: 'not-json' }; continue; }

    let j;
    try { j = JSON.parse(text); } catch (e) { last = { ok: false, stage: 'json-parse' }; continue; }

    const list = j.list || (j.data && j.data.list) || (Array.isArray(j) ? j : null);
    if (!Array.isArray(list)) { last = { ok: false, stage: 'no-list' }; continue; }
    if (list.length < 20) { last = { ok: false, stage: 'few-items', n: list.length }; continue; }

    // 有播放地址的条目数（播放页或直链都算）
    const withPlay = list.filter(it => String(it.vod_play_url || '').trim().length > 0).length;
    if (withPlay < 5) { last = { ok: false, stage: 'no-play-url', n: list.length }; continue; }

    // 只抽 .m3u8 直链去真测片；播放页（/play/xxx、网页地址）不测，算 api-page
    const direct = [];
    for (const it of list.slice(0, 10)) {
      const pu = String(it.vod_play_url || '');
      const m = pu.match(/https?:\/\/[^\s#$"'，]+\.m3u8[^\s#$"'，]*/ig);
      if (m) for (const x of m) if (direct.length < 3) direct.push(x.replace(/&amp;/g, '&'));
    }

    if (direct.length) {
      let tested = 0, lastStage = '';
      for (const u of direct.slice(0, 2)) {
        tested++;
        const d = await deepProbe(u);
        lastStage = d.stage;
        if (d.ok) return { ok: true, stage: 'm3u8-alive', n: list.length, withPlay, tested, verified: true };
      }
      // 直链挂了但接口与播放页正常：仍算活，只是未验证片
      return { ok: true, stage: 'm3u8-dead:' + lastStage, n: list.length, withPlay, tested, verified: false };
    }

    return { ok: true, stage: 'api-page', n: list.length, withPlay, verified: false };
  }

  return last;
}

async function maintainVod(ts, say) {
  const got1 = await ghApiGet('libretv-sub3.json');
  const got2 = await ghApiGet('okys7.json');
  if (got1.status !== 200 || got2.status !== 200) {
    say(`点播：配置文件读取失败 ${got1.status}/${got2.status}`);
    return { skipped: true, reason: 'read-json' };
  }
  let libretv, okys;
  try { libretv = JSON.parse(got1.text); okys = JSON.parse(got2.text); } catch (e) {
    say('点播：JSON 解析失败');
    return { skipped: true, reason: 'parse-json' };
  }

  // 读历史
  const histRaw = await ghApiGet('config/vod-history.json');
  let hist = { updated: '', sites: {} };
  if (histRaw.status === 200 && histRaw.text) {
    try { hist = JSON.parse(histRaw.text); } catch (e) { hist = { updated: '', sites: {} }; }
  }
  if (!hist.sites) hist.sites = {};

  // 统一站点清单（按 url 去重，保留两份里的引用关系）
  const urlToLibName = {};
  for (const s of (libretv.sources || [])) urlToLibName[s.url] = s.name;
  const urlToOkName = {};
  for (const s of (okys.sites || [])) urlToOkName[vodUrlOf(s)] = vodNameOf(s);

  const allUrls = Array.from(new Set([].concat(
    (libretv.sources || []).map(s => s.url),
    (okys.sites || []).map(vodUrlOf)
  )));

  say(`点播：站点 ${allUrls.length} 个（libretv ${(libretv.sources || []).length} / okys ${(okys.sites || []).length}）`);

  const probes = await poolMap(allUrls, Math.min(CFG.conc, 6), async (u) => {
    const name = urlToLibName[u] || urlToOkName[u] || u;
    const r = await vodProbe({ url: u, name });
    return Object.assign({ url: u, name }, r);
  });

  const pass = probes.filter(r => r.ok);
  const fail = probes.filter(r => !r.ok);
  say(`点播：通过 ${pass.length} / ${allUrls.length}`);

  // ---- 候选池：测通就进（和直播那套同一节奏，只是对象换成采集站）----
  const poolRaw = await ghApiGet('config/vod-pool.json');
  let pool = { updated: '', candidates: [] };
  if (poolRaw.status === 200 && poolRaw.text) {
    try { pool = JSON.parse(poolRaw.text); } catch (e) { pool = { updated: '', candidates: [] }; }
  }
  if (!Array.isArray(pool.candidates)) pool.candidates = [];

  // 每一轮先自己找源：抓活配置 → 抽采集站 → 并入候选池，然后才实测
  const poolMerge = { read: false, new: 0, cfgOk: 0, cfgTried: 0, hosts: 0 };
  let foundHosts = [];
  try {
    const disc = await discoverVodSources(say);
    foundHosts = disc.hosts || [];
    poolMerge.cfgOk = disc.ok;
    poolMerge.cfgTried = disc.tried;
    poolMerge.hosts = foundHosts.length;
    poolMerge.read = true;
  } catch (e) {
    say('点播：自动找源失败 ' + String(e).slice(0, 60));
  }
  // 扫源环节如果另存了产物，一并吃进来做补充（没有不影响）
  try {
    const candRaw = await ghApiGet('out/vod-candidates.json');
    if (candRaw.status === 200 && candRaw.text) {
      const cd = JSON.parse(candRaw.text);
      for (const h of (cd.hosts || [])) if (h && h.host) foundHosts.push(h);
    }
  } catch (e) { /* ignore */ }

  if (foundHosts.length) {
    const haveHosts = new Set();
    for (const u of allUrls) { try { haveHosts.add(new URL(u).host); } catch (e) { /* ignore */ } }
    for (const c of pool.candidates) { try { haveHosts.add(new URL(c.api).host); } catch (e) { /* ignore */ } }

    let addedIn = 0;
    for (const h of foundHosts) {
      if (addedIn >= CFG.poolMaxAdd) break;
      if (haveHosts.has(h.host)) continue;
      let api = String(h.api || '').trim();
      if (!api) api = 'http://' + h.host + '/api.php/provide/vod/';
      api = api.replace(/\\\//g, '/').replace(/[?#].*$/, '').replace(/\/+$/, '');
      if (api.indexOf('/api.php/provide/vod') < 0) api = 'http://' + h.host + '/api.php/provide/vod';
      if (!/at\/json$/.test(api)) api += (api.slice(-1) === '/' ? '' : '/') + 'at/json';
      const baseKey = h.host.replace(/^www\./, '').replace(/[^a-zA-Z0-9]/g, '').slice(0, 6) || ('vd' + addedIn);
      pool.candidates.push({
        name: h.host, key: baseKey, api, match: '',
        from: 'auto', seen: h.count || 0, failStreak: 0,
      });
      haveHosts.add(h.host);
      addedIn++;
    }
    poolMerge.new = addedIn;

    // 池子上限：超了就按"被多少配置引用 + 连败次数少"优先保留
    if (pool.candidates.length > CFG.poolMaxPool) {
      pool.candidates.sort((a, b) => ((b.seen || 0) - (a.seen || 0)) || ((a.failStreak || 0) - (b.failStreak || 0)));
      const cut = pool.candidates.length - CFG.poolMaxPool;
      pool.candidates = pool.candidates.slice(0, CFG.poolMaxPool);
      say(`点播：候选池超上限，裁剪 ${cut} 个引用最少的`);
    }
    say(addedIn
      ? `点播：本轮新入池 ${addedIn} 个（池 ${pool.candidates.length}）`
      : `点播：无新站（${foundHosts.length} 个域名均在池或在册）`);
  }

  const inBook = new Set(allUrls);
  const candNew = pool.candidates.filter(c => c && c.api && !inBook.has(c.api) && !(c.failStreak >= 3));
  let candProbes = [];
  if (candNew.length) {
    say(`点播：候选池 ${candNew.length} 个待测`);
    candProbes = await poolMap(candNew, Math.min(CFG.conc, 6), async (c) => {
      const r = await vodProbe({ url: c.api, name: c.name });
      return Object.assign({ cand: c }, r);
    });
  }

  const addedSites = [];
  for (const r of candProbes) {
    const c = r.cand;
    c.lastCheck = ts; c.lastStage = r.stage; c.lastOk = !!r.ok;
    if (!r.ok) {
      c.failStreak = (c.failStreak || 0) + 1;
      say(`点播候选 ${c.name} 不通：${r.stage}（连败 ${c.failStreak}）`);
      continue;
    }
    c.failStreak = 0;
    const target = (c.match || '').trim();
    const libIdx = target ? (libretv.sources || []).findIndex(s => s.name === target) : -1;
    const okIdx = target ? (okys.sites || []).findIndex(s => s.name === target) : -1;
    if (libIdx >= 0 || okIdx >= 0) {
      if (libIdx >= 0) libretv.sources[libIdx].url = c.api;
      if (okIdx >= 0) okys.sites[okIdx].api = c.api;
      const oldUrl = libIdx >= 0 ? libretv.sources[libIdx].url : '';
      addedSites.push({ name: target, url: c.api, how: '换域名', stage: r.stage });
      say(`点播候选 ${c.name} 测通(${r.stage})，替换 ${target} 的域名 → ${c.api}`);
      hist.sites[c.api] = { name: target, failStreak: 0, lastOk: ts, lastCheck: ts, lastStage: r.stage, history: [{ ts, ok: true, stage: r.stage }] };
      if (oldUrl && oldUrl !== c.api) delete hist.sites[oldUrl];
    } else {
      libretv.sources = libretv.sources || [];
      libretv.sources.push({ name: c.name, url: c.api, isAdult: false });
      okys.sites = okys.sites || [];
      okys.sites.push({ key: c.key || c.name, name: c.name, type: 1, api: c.api, searchable: 1, quickSearch: 1, filterable: 1, ext: '' });
      addedSites.push({ name: c.name, url: c.api, how: '新增', stage: r.stage });
      say(`点播候选 ${c.name} 测通(${r.stage})，作为新站追加`);
      hist.sites[c.api] = { name: c.name, failStreak: 0, lastOk: ts, lastCheck: ts, lastStage: r.stage, history: [{ ts, ok: true, stage: r.stage }] };
    }
  }
  if (candProbes.length) {
    say(`点播：候选测 ${candProbes.length}，可进 ${addedSites.length}`);
  }
  pool.updated = ts;

  // 更新历史与连败计数
  const toDelete = [];
  for (const r of probes) {
    const h = hist.sites[r.url] || { name: r.name, failStreak: 0, lastOk: '', history: [] };
    h.name = r.name;
    h.lastCheck = ts;
    h.lastStage = r.stage;
    if (r.ok) {
      h.failStreak = 0;
      h.lastOk = ts;
    } else {
      h.failStreak = (h.failStreak || 0) + 1;
    }
    h.history = (h.history || []).concat([{ ts, ok: !!r.ok, stage: r.stage, code: r.code || 0, n: r.n || 0 }]).slice(-10);
    hist.sites[r.url] = h;
    if (!r.ok && h.failStreak >= 2) toDelete.push(r.url);
  }
  hist.updated = ts;

  let deleted = [];
  if (toDelete.length && !CFG.vodDryRun) {
    const beforeLib = (libretv.sources || []).length;
    const beforeOk = (okys.sites || []).length;
    libretv.sources = (libretv.sources || []).filter(s => toDelete.indexOf(s.url) < 0);
    okys.sites = (okys.sites || []).filter(s => toDelete.indexOf(vodUrlOf(s)) < 0);
    deleted = toDelete.slice();
    say(`点播：剔除 ${deleted.length}（libretv ${beforeLib}→${libretv.sources.length} / okys ${beforeOk}→${okys.sites.length}）`);
  } else if (toDelete.length) {
    say(`点播：[空跑] 本应剔除 ${toDelete.length}：${toDelete.map(u => hist.sites[u] && hist.sites[u].name).join('、')}`);
  }

  // 写回
  let push = {};
  if (!CFG.localProbeOnly) {
    if (deleted.length || addedSites.length) {
      const note = [deleted.length ? '剔除死站' : '', addedSites.length ? '补新站' : ''].filter(Boolean).join('+');
      push.libretv = await ghPut('libretv-sub3.json', JSON.stringify(libretv, null, 2), got1.sha, 'vod: ' + note + ' ' + ts);
      push.okys = await ghPut('okys7.json', JSON.stringify(okys, null, 2), got2.sha, 'vod: ' + note + ' ' + ts);
    }
    push.pool = await ghPut('config/vod-pool.json', JSON.stringify(pool, null, 2), poolRaw.sha, 'vod: 候选池 ' + ts);
    push.hist = await ghPut('config/vod-history.json', JSON.stringify(hist, null, 2), histRaw.sha, 'vod: 判活记录 ' + ts);
  }

  return {
    total: allUrls.length,
    pass: pass.length,
    fail: fail.length,
    candTotal: candNew.length,
    poolNew: poolMerge.new,
    poolRead: poolMerge.read,
    poolSize: pool.candidates.length,
    candAdded: addedSites,
    wouldDelete: toDelete.map(u => ({ url: u, name: (hist.sites[u] || {}).name, streak: (hist.sites[u] || {}).failStreak })),
    deleted,
    dryRun: CFG.vodDryRun,
    detail: probes.map(r => ({ name: r.name, url: r.url, ok: !!r.ok, stage: r.stage, n: r.n || 0, code: r.code || 0, verified: !!r.verified, err: r.err || '' })),
    push,
  };
}

exports.handler = async function (event, context) {
  const t0 = Date.now();
  const log = [];
  const say = (m) => { log.push(m); console.log(m); };

  if (!CFG.token) return { ok: false, msg: 'GH_TOKEN 未配置' };

  const ts = new Date().toISOString();

  // 本地只探点播模式
  if (CFG.localProbeOnly) {
    const vod = await maintainVod(ts, say);
    return { ok: true, mode: 'local-probe-only', ms: Date.now() - t0, vod, log };
  }

  // 1. 读配置
  let chRes = await ghApiGet('config/channels.json');
  let cfg;
  if (chRes.status === 200 && chRes.text) {
    try { cfg = JSON.parse(chRes.text); } catch (e) { return { ok: false, msg: 'channels.json 解析失败' }; }
  } else {
    const raw = await ghRawGet('config/channels.json');
    if (raw.status !== 200) return { ok: false, msg: 'channels.json 读取失败 ' + raw.status };
    try { cfg = JSON.parse(raw.text); } catch (e) { return { ok: false, msg: 'channels.json 解析失败(raw)' }; }
  }
  const chs = cfg.channels || [];
  say('台数 ' + chs.length);

  // 2. 读候选
  const candRaw = await ghRawGet('out/candidates.json');
  let cands = [];
  if (candRaw.status === 200 && candRaw.text) {
    try { cands = (JSON.parse(candRaw.text).candidates || []); } catch (e) { cands = []; }
  }
  say('候选 ' + cands.length + ' 条');

  const seen = new Set();
  const uniq = [];
  for (const c of cands) {
    const k = c.name + '|' + c.url;
    if (seen.has(k)) continue;
    seen.add(k);
    uniq.push(c);
  }
  say('去重后 ' + uniq.length + ' 条');

  // 2.45 实测台名表：人工抽帧确认过的 host:port→编号→台名，优先级高于学来的编号表
  let verified = {};
  try {
    const vRaw = await ghApiGet(VERIFIED_PATH);
    if (vRaw.status === 200 && vRaw.text) {
      const vj = JSON.parse(vRaw.text);
      verified = (vj && vj.stations) || {};
    }
    say(`实测表：${Object.keys(verified).length} 个源站`);
  } catch (e) { say('实测表读取异常 ' + String(e).slice(0, 80)); }

  // 2.5 自己找直播源：国内出口抓活配置 → 抽直播清单 → 按台名对齐（原 3:00 GitHub 扫源搬到云端）
  let disc = { cfgOk: 0, cfgTried: 0, listOk: 0, listTried: 0, pairs: 0, chsHit: 0, cands: [] };
  if (CFG.liveDiscover) {
    try {
      disc = await discoverLiveSources(chs, say);
      for (const d of (disc.cands || [])) {
        const k = d.name + '|' + d.url;
        if (seen.has(k)) continue;
        seen.add(k);
        uniq.push(d);
      }
      say('并入直播候选后 ' + uniq.length + ' 条');
    } catch (e) {
      say('直播找源异常 ' + String(e).slice(0, 120));
    }

    // 编号表复刻：同学区/同格式源站共用一套编号，批量造候选
    try {
      const cbr = await discoverByCodebook(chs, say, verified);
      disc.codebook = {
        ports: cbr.ports, codes: cbr.codes, stations: cbr.stations,
        cands: (cbr.cands || []).length, listOk: cbr.listOk, listTried: cbr.listTried,
      };
      for (const d of (cbr.cands || [])) {
        const k = d.name + '|' + d.url;
        if (seen.has(k)) continue;
        seen.add(k);
        uniq.push(d);
      }
      say('并入编号表候选后 ' + uniq.length + ' 条');
    } catch (e) {
      say('编号表异常 ' + String(e).slice(0, 120));
    }
  }

  // 2.6 社区源：每天去 GitHub 拉社区直播清单，只给当轮"待补台"匹配
  try {
    const cbc = await discoverFromCommunity(chs, say);
    disc.community = { tried: cbc.tried, ok: cbc.ok, pairs: cbc.pairs, chs: cbc.chs, cands: (cbc.cands || []).length, ms: cbc.ms };
    for (const d of (cbc.cands || [])) {
      const k = d.name + '|' + d.url;
      if (seen.has(k)) continue;
      seen.add(k);
      uniq.push(d);
    }
    say('并入社区源候选后 ' + uniq.length + ' 条');
  } catch (e) {
    say('社区源异常 ' + String(e).slice(0, 120));
  }

  // 2.7 现有主线一起测（才知道哪条已经死了），并按缺线数量排序：裸台优先测
  //     已测活且 3 天内测过的台不重测，把测活时间让给没线的台
  const STALE_MS = 3 * 24 * 3600 * 1000;
  const lineOf = {};
  let mainSkip = 0;
  for (const c of chs) {
    lineOf[c.name] = (c.main ? 1 : 0) + (c.backup || []).filter(Boolean).length;
    if (c.main) {
      const lastMs = c.lastCloud ? Date.parse(c.lastCloud) : 0;
      const fresh = c.cloud === 'ok' && lastMs && (Date.now() - lastMs < STALE_MS);
      if (fresh) { mainSkip++; continue; }
      const k = c.name + '|' + c.main;
      if (!seen.has(k)) { seen.add(k); uniq.push({ name: c.name, url: c.main, from: 'current-main' }); }
    }
  }
  say(`现有主线免测 ${mainSkip} 台（3 天内已测活）`);
  uniq.sort((a, b) => (lineOf[a.name] || 0) - (lineOf[b.name] || 0));
  say('并入现有主线后待测 ' + uniq.length + ' 条（裸台优先）');

  // 3. 直播深测（带硬期限：到点就停，剩下的跳过，保证能走到写回和点播）
  const probeDeadline = t0 + CFG.liveProbeMs;
  let probeSkip = 0;
  const results = await poolMap(uniq, CFG.conc, async (c) => {
    if (Date.now() > probeDeadline) {
      probeSkip++;
      return { name: c.name, url: c.url, station: c.station, id: c.id, ok: false, stage: 'skip-deadline' };
    }
    const r = await deepProbe(c.url);
    return Object.assign({ name: c.name, url: c.url, station: c.station, id: c.id, port: c.port, trusted: c.trusted }, r);
  });
  const pass = results.filter(r => r.ok);
  say(`直播测完 通过 ${pass.length} / ${results.length}（超时跳过 ${probeSkip}）`);

  // 4. 合并：固定四组只加不删
  const byName = {};
  for (const c of chs) byName[c.name] = c;

  // 4.0 先按实测表纠正挂错台的线，再把"编号表未验证"的线摘进待选池（主线不动，风险太大）
  const pendingItems = [];
  const pendingUrls = new Set();
  const portOf = (u) => {
    try { const x = new URL(u); return String(x.port || (x.protocol === 'https:' ? 443 : 80)); }
    catch (e) { return ''; }
  };
  const vLook = (u) => {
    const mm = String(u).match(TS_RX);
    if (!mm) return null;
    const vb = verified[mm[1] + ':' + mm[2]];
    if (!vb || !Object.prototype.hasOwnProperty.call(vb, mm[3])) return null;
    return vb[mm[3]] || '';
  };

  // 4.01 实测改判：编号命中实测表但台名不符 → 从当前台摘掉，搬到实测台名下
  const hostOf = (u) => { try { return new URL(u).host; } catch (e) { return String(u); } };
  let remapMove = 0, remapDrop = 0;
  const moveTo = {};
  for (const c of chs) {
    const bk = (c.backup || []).filter(Boolean);
    if (!bk.length) continue;
    const keep = [];
    for (const u of bk) {
      const actual = vLook(u);
      if (actual === null) { keep.push(u); continue; }
      if (!actual) { remapDrop++; continue; }
      if (actual === c.name) { keep.push(u); continue; }
      (moveTo[actual] = moveTo[actual] || []).push(u);
      remapMove++;
    }
    c.backup = keep;
  }
  for (const nm of Object.keys(moveTo)) {
    const c = byName[nm];
    if (!c) continue;
    const bk = (c.backup || []).filter(Boolean).slice();
    for (const u of moveTo[nm]) {
      if (u === c.main || bk.indexOf(u) >= 0) continue;
      if (bk.length >= CFG.backupMax) continue;
      const usedHosts = new Set([hostOf(c.main)].concat(bk.map(hostOf)));
      if (usedHosts.has(hostOf(u))) continue;
      bk.push(u);
    }
    if (bk.length !== (c.backup || []).filter(Boolean).length) {
      c.backup = bk;
      if (!/实测改判/.test(c.note || '')) c.note = c.note ? (c.note + '｜实测改判') : '实测改判';
    }
  }
  if (remapMove || remapDrop) say(`实测表改判：搬走 ${remapMove} 条、摘掉 ${remapDrop} 条`);

  // 4.02 剩下的"编号表未验证、实测表也没有"的备线摘进待选池
  for (const c of chs) {
    const bk = (c.backup || []).filter(Boolean);
    if (!bk.length) continue;
    const keep = [];
    for (const u of bk) {
      const isCb = /\/tsfile\/live\/\d+_\d+/.test(u);
      const p = portOf(u);
      if (isCb && !TRUSTED_PORTS.has(p) && vLook(u) === null) {
        pendingItems.push({ name: c.name, url: u, port: p, src: 'moved-from-backup', reason: '编号表未验证（端口 ' + p + '）' });
        pendingUrls.add(u);
      } else keep.push(u);
    }
    c.backup = keep;
  }
  if (pendingItems.length) say(`待选池：从已有备线摘出 ${pendingItems.length} 条可疑线`);

  const resByUrl = new Map();
  for (const r of results) resByUrl.set(r.url, r);

  let added = 0, marked = 0, promoted = 0, skipped = 0, deadMain = 0;
  const gotLive = new Set();
  for (const p of pass) gotLive.add(p.name);

  // 先判主线死活（本轮的测活结果里能找到主线的，就以它为准）
  for (const c of chs) {
    if (!c.main) continue;
    const r = resByUrl.get(c.main);
    if (r && !r.ok) { c.cloud = 'fail'; deadMain++; c.lastCloud = ts; }
    else if (r && r.ok) { c.cloud = 'ok'; c.lastCloud = ts; }
  }
  say(`主线测死 ${deadMain} 台`);

  for (const p of pass) {
    const c = byName[p.name];
    if (!c) { skipped++; continue; }

    // 编号表未验证的端口：测通也不挂到台，只进待选池，等本地抽帧鉴定
    if (p.trusted === false) {
      if (!pendingUrls.has(p.url)) {
        pendingUrls.add(p.url);
        pendingItems.push({ name: p.name, url: p.url, port: String(p.port || ''), src: 'codebook', reason: '编号表未验证（端口 ' + String(p.port || '?') + '）' });
      }
      continue;
    }

    if (c.cloud !== 'ok') { c.cloud = 'ok'; marked++; }
    c.lastCloud = ts;

    const has = (c.main === p.url) || (c.backup || []).includes(p.url);
    if (has) continue;

    if (!c.main || c.cloud === 'fail' || c.local === 'fail' || c.local === 'none') {
      const old = c.main;
      const bk = (c.backup || []).filter(x => x !== p.url);
      if (old) bk.push(old);
      while (bk.length > CFG.backupMax) bk.shift();
      c.main = p.url;
      c.backup = bk;
      c.cloud = 'ok';
      c.local = 'untested';
      c.note = '华为云顶上';
      promoted++;
      continue;
    }

    const bk = (c.backup || []).slice();
    if (bk.length >= CFG.backupMax) { skipped++; continue; }
    // 已有备线时要求新线来自不同 host，避免同一个源站整体挂时连备线一起没
    if (bk.length > 0) {
      const usedHosts = new Set([hostOf(c.main)].concat(bk.map(hostOf)));
      if (usedHosts.has(hostOf(p.url))) { skipped++; continue; }
    }
    bk.push(p.url);
    c.backup = bk;
    added++;
  }
  say(`标记 ${marked}  加备线 ${added}  顶上主线 ${promoted}  跳过 ${skipped}`);

  // 4.5 死台兜底标记：主线本轮测死且一条备线都没有 → 标〔待补〕；恢复活的自动摘掉
  let pendingCnt = 0;
  for (const c of chs) {
    const bk = (c.backup || []).filter(Boolean);
    if (c.cloud === 'fail' && !bk.length) {
      if (!/待补/.test(c.note || '')) c.note = c.note ? (c.note + '｜待补') : '〔待补〕';
      pendingCnt++;
    } else if (c.cloud === 'ok' && /待补/.test(c.note || '')) {
      const cleaned = String(c.note || '').replace(/〔?待补〕?/g, '').replace(/^｜+|\｜+$/g, '').trim();
      c.note = cleaned || null;
    }
  }
  say(`〔待补〕台 ${pendingCnt}`);

  // 5. 体育娱乐组动态增删
  let ent = { tested: 0, removed: [], added: [], relinked: 0 };
  try { ent = await maintainEnt(chs, uniq, ts, say); } catch (e) { say('体育娱乐处理异常 ' + String(e).slice(0, 120)); }

  // 6. 点播
  let vod = null;
  if (Date.now() - t0 < CFG.budget) {
    try { vod = await maintainVod(ts, say); } catch (e) { say('点播处理异常 ' + String(e).slice(0, 120)); }
  } else {
    say('点播：超预算跳过');
  }

  // 7. 写回主清单
  cfg.updated = ts;
  const chText = JSON.stringify(cfg, null, 2);
  const liveText = buildM3U(chs);
  const bckText = buildBck(chs);
  const rep = {
    ts, scanned: results.length, pass: pass.length,
    marked, added, promoted, skipped,
    pending: pendingItems.length,
    ent, vod,
    community: disc.community || null,
    detail: results.map(r => ({ name: r.name, url: r.url, ok: !!r.ok, stage: r.stage, bytes: r.bytes || 0 })),
    log,
  };

  const st1 = await ghPut('config/channels.json', chText, chRes.sha, 'cloud: 深度测并标记 ' + ts);
  const lRaw = await ghApiGet('out/live.m3u');
  const st2 = await ghPut('out/live.m3u', liveText, lRaw.sha, 'cloud: 更新主清单 ' + ts);
  const bRaw = await ghApiGet('out/backup.m3u');
  const st3 = await ghPut('out/backup.m3u', bckText, bRaw.sha, 'cloud: 更新备线池 ' + ts);
  const rRaw = await ghApiGet('out/cloud-report.json');
  const st4 = await ghPut('out/cloud-report.json', JSON.stringify(rep, null, 2), rRaw.sha, 'cloud: 报告 ' + ts);

  // 待选池：测通但映射没验证的线，单独存一份，不并进 App 用的清单
  const pendText = JSON.stringify({ updated: ts, count: pendingItems.length, items: pendingItems }, null, 2);
  const pRaw = await ghApiGet('config/live-pending.json');
  const st5 = await ghPut('config/live-pending.json', pendText, pRaw.sha, 'cloud: 更新待选池 ' + ts);

  return {
    ok: true,
    ms: Date.now() - t0,
    total: results.length,
    pass: pass.length,
    marked, added, promoted, skipped,
    ent: { added: ent.added, removed: ent.removed, relinked: ent.relinked },
    vod: vod ? { total: vod.total, pass: vod.pass, fail: vod.fail, deleted: (vod.deleted || []).length, dryRun: vod.dryRun } : null,
    pushed: { channels: st1, live: st2, backup: st3, report: st4 },
    log,
  };
};

// 测试钩子（云端运行不受影响）
exports.__discoverLiveSources = discoverLiveSources;
exports.__chKey = chKey;
exports.__matchChannel = matchChannel;
exports.__parseLivePlaylist = parseLivePlaylist;
exports.__deepProbe = deepProbe;
exports.__discoverByCodebook = discoverByCodebook;
exports.__discoverFromCommunity = discoverFromCommunity;
exports.__buildCodebookCands = buildCodebookCands;
exports.__learnCodebook = learnCodebook;
